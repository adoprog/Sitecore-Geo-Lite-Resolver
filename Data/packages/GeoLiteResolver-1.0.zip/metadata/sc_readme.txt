The package will install the following files:

/bin/Sitecore.SharedSource.GeoLiteResolver.dll
/App_Config/Include/Sitecore.SharedSource..GeoLiteResolver.config
/App_Data/GeoIP.dat

and items:
/sitecore/system/Settings/Rules/Conditional Renderings/Conditions/Geo IP/Country Condition

Don't forget to publish the site after you install the package.

This product includes GeoLite data created by MaxMind, available from
http://maxmind.com/

There are two licenses, one for the C library software, and one for
the database.

SOFTWARE LICENSE (C library)

The GeoIP C Library is licensed under the LGPL.  For details see
the COPYING file.

OPEN DATA LICENSE (GeoLite Country and GeoLite City databases)

Copyright (c) 2008 MaxMind, Inc.  All Rights Reserved.

All advertising materials and documentation mentioning features or use of
this database must display the following acknowledgment:
"This product includes GeoLite data created by MaxMind, available from
http://maxmind.com/"